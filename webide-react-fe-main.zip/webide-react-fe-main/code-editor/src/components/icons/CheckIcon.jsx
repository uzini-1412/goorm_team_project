const CheckIcon = ({ className = "icon" }) => (
  <svg
    className={className}
    viewBox="0 0 512 512"
    xmlns="http://www.w3.org/2000/svg"
    fill="currentColor"
    preserveAspectRatio="xMidYMid meet"
  >
    <g transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)"
      stroke="none">
      <path d="M4400 4454 c-36 -7 -99 -30 -140 -50 -73 -35 -109 -70 -1170 -1129
      -602 -601 -1109 -1100 -1127 -1109 -37 -19 -80 -20 -120 -5 -15 5 -224 205
      -463 443 -407 404 -440 434 -510 469 -98 48 -176 67 -275 67 -342 0 -614 -288
      -592 -625 7 -99 35 -191 83 -271 28 -47 205 -230 753 -777 687 -686 719 -716
      791 -751 180 -87 354 -86 540 5 l85 41 1348 1347 c741 740 1365 1369 1387
      1396 142 184 168 417 69 625 -116 246 -392 382 -659 324z"/>
    </g>
</svg>
);

export default CheckIcon;
